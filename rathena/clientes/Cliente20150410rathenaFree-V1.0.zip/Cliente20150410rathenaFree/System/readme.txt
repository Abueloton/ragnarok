
Put both itemInfo.lua and kRO.lua in system folder
they are integrated, so you won't miss any kRO items

-- Special thanks to NEO, so it's possible to use the secondary itemInfo.lua
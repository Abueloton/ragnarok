# ROenglishRE - Ragnarok Online REnewal english translation project
Project created by zackdreaver - 2015

About this project:
- English translation of renewal items from many official servers
- Fast update of translation
- Better translation than official's
- Follow kRO's item description
